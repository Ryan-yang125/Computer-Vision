To run this script:
1.ensure you have `python >= 3.7.6` in your pc
2.run `pip install`
3.run `python ./main.py`
